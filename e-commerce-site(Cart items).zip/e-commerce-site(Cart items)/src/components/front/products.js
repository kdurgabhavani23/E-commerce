import React from "react";
import './product.css'
const Products = ({productItem,handleAddproduct,handleRemoveproduct,cartItemas}) =>{
    // const data=[
    //     {

    //         id:"1",
    //         name:"Mango",
    //         price:100 ,
    //         Image:"./images/mango-min.png" 
   
    //         },
    //         {
   
    //            id:"2",
    //            name:"Apple",
    //            price:150 ,
    //            Image:"./images/apple-min.png" 
      
    //            },
    // ]
    return(
        <div className="products">
           
            {
                productItem.map((productItems)=>(
                   
                    <div className="card">
                        <div>
                            <img className="product-image" src={productItems.Image}></img>
                        </div>
                        <div>
                            <h4 className="product-name">{productItems.name}</h4>
                        </div>
                        
                        <div className="product-price">${productItems.price}</div>
                        <div>
                            
                            <button className="product-add-button" onClick={()=>handleAddproduct(productItems)}>Add to cart</button>
                           
                        </div>
                    </div>
                 

                ))
            }
            {/* {
                data.map((productItems)=>(
                    <div>
                        <div class="card">
                            <div class="card-body">
                            <div>
                                <img src={productItems.Image}></img>
                            </div>
                            </div>
                        </div>
                    </div>

                ))
               
                
                
            } */}
            
        </div>
    )
}

export default Products;