import React from "react";
const Signup=()=>{
    return(
        <div>
            <h1 className="sign" style={{marginTop:"30px"}}>welcome to signup</h1>
        </div>
    )
}
export default Signup;