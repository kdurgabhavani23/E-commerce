import React from "react";
import './header.css'
import {Link} from"react-router-dom";
const Header = ({cartItemas,productItem}) =>{
    return(
        <div>
                <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
 
 

 
  <ul class="navbar-nav">
    <li class="nav-item">
      <Link to="/" className="color">Home</Link>
    </li>
    <li class="nav-item">
      <Link to="/Signup" className="color">Sign in</Link>
    </li>
    <li class="nav-item">
      <Link to="/Cart" className="color"><i class="fas fa-shopping-cart"></i>
      <span>{cartItemas.length === 0 ? '': cartItemas.length}</span>
     </Link>

    </li>
   
    
  </ul>
</nav>


            </div>
    )
}
export default Header;