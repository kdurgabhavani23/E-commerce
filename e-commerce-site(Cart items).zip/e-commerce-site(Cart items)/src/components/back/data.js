const data={
    productItem:[
        {

         id:"1",
         name:"Mango",
         price:100 ,
         Image:"./images/mango-min.png" 

         },
         {

            id:"2",
            name:"Apple",
            price:150 ,
            Image:"./images/apple-min.png" 
   
            },
            {

                id:"3",
                name:"Banana",
                price:90 ,
                Image:"./images/banana-min.png" 
       
                },
                {

                    id:"4",
                    name:"Orange",
                    price:170 ,
                    Image:"./images/orange-min.png" 
           
                    },
                    {

                        id:"5",
                        name:"Grapes",
                        price:130 ,
                        Image:"./images/grapes-min.png" 
               
                        },
                        {

                            id:"6",
                            name:"Pineapple",
                            price:150 ,
                            Image:"./images/pineapple-min.png" 
                   
                            },
                            
    ]
}
export default data;