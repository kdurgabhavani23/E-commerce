import logo from './logo.svg';
import React from 'react';
import './App.css';
import data from './components/back/data';
import Header from './components/front/header';
import {BrowserRouter as Router} from "react-router-dom"
import Routes from './components/front/Route';
import { useState } from 'react';
function App() {
  const{ productItem}= data;
  const [cartItemas, setCartItems] = useState([]);
const handleAddproduct = (product)=>{
  const ProductExist= cartItemas.find((item)=> item.id === product.id);
  if(ProductExist){
    setCartItems(
      cartItemas.map((item)=>
      item.id === product.id ? {...ProductExist,qunatity: ProductExist.qunatity + 1}:item
      )
    );

  }
  else{
    setCartItems([...cartItemas, { ...product,qunatity:1}]);

  }
}
const handleRemoveproduct = (product)=>{
  const ProductExist= cartItemas.find((item)=> item.id === product.id);
  if(ProductExist.qunatity === 1){
    setCartItems(cartItemas.filter((item)=> item.id !== product.id));

  }
  else{
    setCartItems(
      cartItemas.map((item)=>
      item.id === product.id ? {...ProductExist,qunatity:ProductExist.qunatity - 1 }: item
      )
    );
  }
}
const handleCartclear = ()=>{
  setCartItems([])
}
  return (
    <div className="App">
      <Router>
      <Header cartItemas={cartItemas}></Header>
      <Routes productItem={productItem} cartItemas={cartItemas} handleAddproduct={handleAddproduct} handleRemoveproduct={handleRemoveproduct} handleCartclear={handleCartclear}></Routes>
      </Router>
      
     


      {/* {
        productItem.map((item)=>(
          <div><img src={item.Image}></img></div>
          
          ))
      } */}
    </div>
  );
}

export default App;
